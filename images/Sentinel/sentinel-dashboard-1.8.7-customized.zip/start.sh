#!/bin/bash
pid=$(ps -ef | grep sentinel-dashboard-1.8.7-customized.jar | grep -v grep | awk '{print $2}')
kill -9 $pid
nohup java -Dserver.port=8180 -Dnacos.serverAddr=localhost:8848 -Dsentinel.dashboard.auth.username=sentinel -Dsentinel.dashboard.auth.password=sentinel -Dnacos.namespace=ffcs-test -Dcsp.sentinel.dashboard.server=localhost:8180 -Dproject.name=sentinel-dashboard -jar sentinel-dashboard-1.8.7-customized.jar  > ./info.log &

